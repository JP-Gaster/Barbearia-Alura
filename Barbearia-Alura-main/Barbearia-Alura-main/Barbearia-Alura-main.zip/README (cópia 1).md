# textobase
Texto que servirá de base para criação do site da Barbearia Alura
